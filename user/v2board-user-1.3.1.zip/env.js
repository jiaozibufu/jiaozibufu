window.settings = {
  // 站点标题
  title: 'Fysee',
  // 站点描述
  description: 'Node is best',
  // API
  host: 'https://panel.wcnm.shop',
  // 主题
  theme: {
    sidebar: 'light',
    header: 'dark',
    color: 'default'
  },
  // 背景
  background_url: ''
}
